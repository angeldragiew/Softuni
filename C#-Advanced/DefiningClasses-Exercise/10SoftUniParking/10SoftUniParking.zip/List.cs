﻿namespace SoftUniParking
{
    public class List
    {
    }
}